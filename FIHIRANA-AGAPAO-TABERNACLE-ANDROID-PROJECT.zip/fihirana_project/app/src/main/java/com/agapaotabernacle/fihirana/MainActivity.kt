package com.agapaotabernacle.fihirana

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.agapaotabernacle.fihirana.data.Hymn
import com.agapaotabernacle.fihirana.data.HymnRepository
import kotlinx.coroutines.launch
import java.text.Normalizer
import java.util.Locale

private val Navy = Color(0xFF0F172A)
private val Blue = Color(0xFF1E3A8A)
private val Gold = Color(0xFFD4A72C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = HymnRepository(applicationContext)
        val hymns = repo.loadHymns()
        setContent { FihiranaTheme { MainApp(repo, hymns) } }
    }
}

@Composable
fun FihiranaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, secondary = Gold, background = Navy, surface = Color(0xFF1E293B)), content = content)
}

@Composable
fun Footer() { Text("Éditeur : Pasteur Zo", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(6.dp)) }

@Composable
fun MainApp(repo: HymnRepository, hymns: List<Hymn>) {
    val nav = rememberNavController()
    val favorites by repo.favoriteIds.collectAsState(initial = emptySet())
    val fontSize by repo.fontSize.collectAsState(initial = 20)
    val scope = rememberCoroutineScope()
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { HomeScreen(nav, hymns) }
        composable("all") { HymnListScreen(nav, hymns, favorites) }
        composable("favorites") { FavoriteScreen(nav, hymns, favorites) }
        composable("reader/{number}") { e ->
            val n = e.arguments?.getString("number")?.toIntOrNull() ?: return@composable
            ReaderScreen(nav, hymns, n, favorites, fontSize,
                onToggle = { scope.launch { repo.toggleFavorite(it) } },
                onFont = { scope.launch { repo.saveFontSize(it) } })
        }
        composable("about") { AboutScreen(nav) }
    }
}

@Composable
fun HomeScreen(nav: NavHostController, hymns: List<Hymn>) {
    Column(Modifier.fillMaxSize().background(Navy).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(30.dp))
        Text("FIHIRANA AGAPAO TABERNACLE", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Gold, textAlign = TextAlign.Center)
        Text("Fihirana 2024", fontSize = 18.sp, color = Color.LightGray)
        Spacer(Modifier.height(28.dp))
        SearchBox(nav, hymns)
        Spacer(Modifier.height(18.dp))
        Button({ nav.navigate("all") }, Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(14.dp)) { Text("HIRA REHETRA", fontSize = 18.sp) }
        Spacer(Modifier.height(12.dp))
        Button({ nav.navigate("favorites") }, Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("HIRA ANKAFIZINA", fontSize = 18.sp, color = Navy) }
        Spacer(Modifier.height(12.dp))
        OutlinedButton({ nav.navigate("about") }, Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(14.dp)) { Text("MOMBA NY APPLI") }
        Spacer(Modifier.weight(1f))
        Footer()
    }
}

@Composable
fun SearchBox(nav: NavHostController, hymns: List<Hymn>) {
    var q by remember { mutableStateOf("") }
    Column {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text("Hikaroka laharana, lohateny, tononkira...") })
        if (q.isNotBlank()) {
            val results = search(hymns, q).take(8)
            LazyColumn(Modifier.heightIn(max = 300.dp)) { items(results) { h ->
                Text("${h.number} – ${h.title}", Modifier.fillMaxWidth().clickable { nav.navigate("reader/${h.number}") }.padding(12.dp), fontSize = 16.sp)
            } }
        }
    }
}

private fun normalize(s: String): String = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace("\\p{M}".toRegex(), "")
private fun search(hymns: List<Hymn>, q: String): List<Hymn> {
    val n = normalize(q.trim())
    return hymns.filter { normalize(it.number.toString()).contains(n) || normalize(it.title).contains(n) || normalize(it.lyrics).contains(n) }.sortedBy { it.number }
}

@Composable
fun HymnListScreen(nav: NavHostController, hymns: List<Hymn>, favorites: Set<Int>) {
    var q by remember { mutableStateOf("") }
    val filtered = search(hymns, q)
    Scaffold(topBar = { TopAppBar(title = { Text("HIRA REHETRA") }, navigationIcon = { IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Miverina") } }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text("Hikaroka...") })
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) { items(filtered, key = { it.number }) { h -> HymnRow(nav, h, favorites.contains(h.number)) } }
            Footer()
        }
    }
}

@Composable
fun HymnRow(nav: NavHostController, h: Hymn, fav: Boolean) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { nav.navigate("reader/${h.number}") }) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(h.number.toString(), color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(55.dp))
            Text(h.title, fontSize = 16.sp, modifier = Modifier.weight(1f))
            if (fav) Icon(Icons.Default.Favorite, "Ankafizina", tint = Color.Red)
        }
    }
}

@Composable
fun FavoriteScreen(nav: NavHostController, hymns: List<Hymn>, favorites: Set<Int>) {
    val list = hymns.filter { it.number in favorites }
    Scaffold(topBar = { TopAppBar(title = { Text("HIRA ANKAFIZINA") }, navigationIcon = { IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Miverina") } }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
            if (list.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) { Text("Tsy misy hira ankafizina aloha.", color = Color.Gray) }
            else LazyColumn(Modifier.weight(1f)) { items(list) { HymnRow(nav, it, true) } }
            Footer()
        }
    }
}

@Composable
fun ReaderScreen(nav: NavHostController, hymns: List<Hymn>, number: Int, favorites: Set<Int>, fontSize: Int, onToggle: (Int) -> Unit, onFont: (Int) -> Unit) {
    val index = hymns.indexOfFirst { it.number == number }
    if (index < 0) return
    val h = hymns[index]
    val prev = hymns.getOrNull(index - 1)
    val next = hymns.getOrNull(index + 1)
    Scaffold(topBar = {
        TopAppBar(title = { Text(h.number.toString()) }, navigationIcon = { IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Miverina") } }, actions = {
            TextButton({ if (fontSize > 14) onFont(fontSize - 2) }) { Text("A−") }
            TextButton({ if (fontSize < 36) onFont(fontSize + 2) }) { Text("A+") }
            IconButton({ onToggle(h.number) }) { Icon(if (h.number in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Ankafizina", tint = if (h.number in favorites) Color.Red else Color.White) }
        })
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(vertical = 14.dp)) {
                Text(h.title, fontSize = 24.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold, color = Gold)
                Spacer(Modifier.height(18.dp))
                Text(h.lyrics, fontSize = fontSize.sp, lineHeight = (fontSize * 1.55f).sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Button({ prev?.let { nav.navigate("reader/${it.number}") } }, enabled = prev != null) { Text("← Previous") }
                Button({ next?.let { nav.navigate("reader/${it.number}") } }, enabled = next != null) { Text("Next →") }
            }
            Footer()
        }
    }
}

@Composable
fun AboutScreen(nav: NavHostController) {
    Scaffold(topBar = { TopAppBar(title = { Text("MOMBA NY APPLI") }, navigationIcon = { IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Miverina") } }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(25.dp)); Text("FIHIRANA AGAPAO TABERNACLE", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center); Text("Fihirana 2024", color = Color.LightGray, fontSize = 18.sp); Spacer(Modifier.height(25.dp))
            Text("Ity fampiharana ity dia kinova nomerika ivelan-tserasera (offline) amin'ny fihirana 2024 nampidirina avy amin'ny boky nomena.", textAlign = TextAlign.Center, fontSize = 17.sp, lineHeight = 26.sp)
            Spacer(Modifier.weight(1f)); Footer()
        }
    }
}
