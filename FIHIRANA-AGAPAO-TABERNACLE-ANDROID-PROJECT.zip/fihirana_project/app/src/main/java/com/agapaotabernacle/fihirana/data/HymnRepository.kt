package com.agapaotabernacle.fihirana.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "fihirana_settings")

data class Hymn(val number: Int, val title: String, val lyrics: String)

class HymnRepository(private val context: Context) {
    private val favoritesKey = stringSetPreferencesKey("favorite_hymns")
    private val fontSizeKey = intPreferencesKey("font_size")

    fun loadHymns(): List<Hymn> {
        val json = context.assets.open("hymns.json").bufferedReader().use { it.readText() }
        val type = object : TypeToken<List<Hymn>>() {}.type
        return Gson().fromJson<List<Hymn>>(json, type).sortedBy { it.number }
    }

    val favoriteIds: Flow<Set<Int>> = context.dataStore.data.map { prefs ->
        prefs[favoritesKey]?.mapNotNull(String::toIntOrNull)?.toSet() ?: emptySet()
    }

    val fontSize: Flow<Int> = context.dataStore.data.map { it[fontSizeKey] ?: 20 }

    suspend fun toggleFavorite(id: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[favoritesKey] ?: emptySet()
            val s = id.toString()
            prefs[favoritesKey] = if (s in current) current - s else current + s
        }
    }

    suspend fun saveFontSize(size: Int) {
        context.dataStore.edit { it[fontSizeKey] = size.coerceIn(14, 36) }
    }
}
